<?php
// 清空聊天记录
file_put_contents('a.txt', '');
?>
