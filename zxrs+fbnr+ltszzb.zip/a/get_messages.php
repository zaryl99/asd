<?php
// 从文件中读取消息
$messages = file_get_contents('a.txt');
echo $messages;
?>

